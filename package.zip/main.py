import streamlit as st

# Configuração da página
st.set_page_config(
    page_title="Sistema de Colaboradores",
    page_icon="🏢",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# CSS personalizado
st.markdown("""
<style>
.main {
    background-color: #1e1e1e;
    color: white;
}

.stApp {
    background-color: #2d2d2d;
}

.css-1d391kg {
    background-color: #2d2d2d;
}

.stTextInput > div > div > input {
    background-color: #404040;
    color: white;
    border: 1px solid #666;
}

.stSelectbox > div > div > div {
    background-color: #404040;
    color: white;
}

.stDateInput > div > div > input {
    background-color: #404040;
    color: white;
}

h1 {
    color: white;
    text-align: center;
    padding: 20px;
    background-color: #333;
    border-radius: 10px;
    margin-bottom: 30px;
}

.success-message {
    background-color: #28a745;
    color: white;
    padding: 10px;
    border-radius: 5px;
    text-align: center;
    margin: 10px 0;
}

.error-message {
    background-color: #dc3545;
    color: white;
    padding: 10px;
    border-radius: 5px;
    text-align: center;
    margin: 10px 0;
}

/* Estilo do navegador superior */
.st-emotion-cache-1jicfl2 {
    background-color: #333 !important;
}

.st-emotion-cache-1jicfl2 .st-emotion-cache-10trblm {
    color: white !important;
}
</style>
""", unsafe_allow_html=True)

# Páginas do sistema
pages = {
    "Menu": [
        st.Page("cadastro.py", title="Cadastro de colaboradores"),
        st.Page("listagem.py", title="Listar/Atualizar/Excluir cadastros")
    ],
    "Sistema": [
        st.Page("sobre.py", title="Sobre o Sistema")
    ]
}

# Navegação no topo
pg = st.navigation(pages, position="top")
pg.run()